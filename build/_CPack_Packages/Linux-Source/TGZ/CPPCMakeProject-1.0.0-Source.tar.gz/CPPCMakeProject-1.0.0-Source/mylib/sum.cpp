#include "sum.hpp"

/**
 * @brief This function calculates sum of given intergers
 * 
 * @param a 
 * @param b 
 * @return int 
 */
int Sum(int a, int b) { return a + b; }