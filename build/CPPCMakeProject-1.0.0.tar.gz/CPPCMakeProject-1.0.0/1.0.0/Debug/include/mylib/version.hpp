//==================================================
// Automatically generated, but not overwritten
//==================================================
// CAVEAT: config.hpp.in is never overwritten, but config.hpp is!
//

#pragma once

/** @file 
 *  @brief MyFirstProject configuration file
 *  
 *  @attention automatically generated from @b config.hpp.in, do not modify!
 */

#define MyFirstProject_VERSION_MAJOR   
#define MyFirstProject_VERSION_MINOR 
#define MyFirstProject_VERSION_PATCH 
#define MyFirstProject_GIT_REVISION "1fddd50ac9f99e7079cf7eb601da098ce5419394"

#define MyFirstProject_SYSTEM_NAME Linux
#define MyFirstProject_HOST_SYSTEM_PROCESSOR x86_64
