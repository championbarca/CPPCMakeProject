#ifndef SUM_HPP
#define SUM_HPP

#include "version.hpp"
#include <iostream>

int Sum(int a, int b);

#endif // SUM_HPP